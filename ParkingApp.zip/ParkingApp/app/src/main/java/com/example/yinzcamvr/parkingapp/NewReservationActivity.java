package com.example.yinzcamvr.parkingapp;

import android.annotation.TargetApi;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Handler;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.CognitoCachingCredentialsProvider;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBMapper;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBMapperConfig;

import java.util.Timer;
import java.util.TimerTask;

public class NewReservationActivity extends AppCompatActivity {

    private Button slot1, slot2, slot3, slot4, reserve;
    private TextView numslots;
    private int slots = 0;
    private String finalnum;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_reservation);

        slot1 = findViewById(R.id.button_slot_1);
        slot2 = findViewById(R.id.button_slot_2);
        slot3 = findViewById(R.id.button_slot_3);
        slot4 = findViewById(R.id.button_slot_4);
        reserve = findViewById(R.id.button_reserve);
        numslots = findViewById(R.id.text_slots_available);


        callAsynchronousTask();

        if(slots==0){
            numslots.setText("There are no slots available.");
        }else{
            finalnum = "There are " + slots +" slots available.";
            numslots.setText(finalnum);
        }

        reserve.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(slots > 0 ){
                    Toast.makeText(getApplicationContext(),"Reservation made",Toast.LENGTH_LONG).show();
                    slots = slots-1;
                }else{
                    Toast.makeText(getApplicationContext(),"No more slots left",Toast.LENGTH_LONG).show();
                }
                if(slots<0){
                    numslots.setText("There are no slots available.");
                }else{
                    finalnum = "There are " + slots +" slots available.";
                    numslots.setText(finalnum);
                }
            }
        });

    }

    public void callAsynchronousTask() {
        final Handler handler = new Handler();
        Timer timer = new Timer();
        TimerTask doAsynchronousTask = new TimerTask() {
            @Override
            public void run() {
                handler.post(new Runnable() {
                    @TargetApi(Build.VERSION_CODES.CUPCAKE)
                    @RequiresApi(api = Build.VERSION_CODES.CUPCAKE)
                    public void run() {
                        try {
                            new retrieveVals().execute();

                        } catch (Exception e) {
                            Log.d("TERR","Error in callAsync");
                        }
                    }
                });
            }
        };
        timer.schedule(doAsynchronousTask, 0, 8000); // will execute  after  1 sec
    }

     private class retrieveVals extends AsyncTask<Void,Integer,Integer> {

        @Override
        protected Integer doInBackground(Void... voids) {
            try {
                slots = 0;
                ManagerClass managerClass = new ManagerClass();
                CognitoCachingCredentialsProvider credentialsProvider = managerClass.getCredentials(NewReservationActivity.this);
                MapperClass mapperClass = new MapperClass();

                if (credentialsProvider != null && mapperClass != null) {
                    Log.d("credentialsProvider:", String.valueOf(credentialsProvider));
                    DynamoDBMapper dynamoDBMapper = managerClass.initDynamoClient(credentialsProvider);
                    DynamoDBMapperConfig dynamoDBMapperConfig = new DynamoDBMapperConfig(DynamoDBMapperConfig.SaveBehavior.UPDATE);
                    // mapperClass.setSensor("4");
                      /*dynamoDBMapper.save(mapperClass,dynamoDBMapperConfig);*/
                    mapperClass.setSensor("3");
                    MapperClass mapperClass1 = new MapperClass();
                    mapperClass1 = dynamoDBMapper.load(MapperClass.class, mapperClass.getSensor(),
                            new DynamoDBMapperConfig(DynamoDBMapperConfig.ConsistentReads.CONSISTENT));


                    if (mapperClass1.getStatus() == "1") {
                        NewReservationActivity.this.runOnUiThread(new Runnable() {
                            public void run() {
                                slot1.setBackgroundColor(Color.RED);

                            }
                        });

                    } else {
                        NewReservationActivity.this.runOnUiThread(new Runnable() {
                            public void run() {
                                slot1.setBackgroundColor(Color.GREEN);
                                slots = slots + 1;
                            }
                        });
                    }
                    mapperClass.setSensor("4");
                    mapperClass1 = dynamoDBMapper.load(MapperClass.class, mapperClass.getSensor(),
                            new DynamoDBMapperConfig(DynamoDBMapperConfig.ConsistentReads.CONSISTENT));
                    if (mapperClass1.getStatus() == "1") {
                        NewReservationActivity.this.runOnUiThread(new Runnable() {
                            public void run() {
                                slot2.setBackgroundColor(Color.RED);
                            }
                        });
                    } else {
                        NewReservationActivity.this.runOnUiThread(new Runnable() {
                            public void run() {
                                slot2.setBackgroundColor(Color.GREEN);
                                slots = slots + 1;
                            }
                        });
                    }
                    mapperClass.setSensor("5");
                    mapperClass1 = dynamoDBMapper.load(MapperClass.class, mapperClass.getSensor(),
                            new DynamoDBMapperConfig(DynamoDBMapperConfig.ConsistentReads.CONSISTENT));
                    if (mapperClass1.getStatus() == "1") {
                        NewReservationActivity.this.runOnUiThread(new Runnable() {
                            public void run() {
                                slot3.setBackgroundColor(Color.RED);
                            }
                        });
                    } else {
                        NewReservationActivity.this.runOnUiThread(new Runnable() {
                            public void run() {
                                slot3.setBackgroundColor(Color.GREEN);
                                slots = slots + 1;

                            }
                        });
                    }


                } else {
                    return 2;
                }


            } catch (AmazonServiceException ase) {
                Log.d("Exception", " Caught! ");
            }

            return 1;
        }

        @Override
        protected void onPostExecute(Integer integer) {
            super.onPostExecute(integer);
            if (integer == 2) {
                Toast.makeText(NewReservationActivity.this, "Not Updated", Toast.LENGTH_SHORT).show();
            }
        }

    }
}
