package com.example.yinzcamvr.parkingapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.Toast;

public class HomeActivity extends AppCompatActivity {

    private CardView reserve,manage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        reserve = findViewById(R.id.card_new_reservation);
        manage = findViewById(R.id.card_manage_reservation);

        reserve.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"Going to new reservation", Toast.LENGTH_SHORT);
                Intent intent = new Intent(HomeActivity.this,NewReservationActivity.class);
                startActivity(intent);

            }
        });

        manage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"Going to manage reservation", Toast.LENGTH_SHORT);
                Intent intent = new Intent(HomeActivity.this,ManageReservationActivity.class);
                startActivity(intent);
            }
        });
    }
}
