package com.example.yinzcamvr.parkingapp;

import android.util.Log;

import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBAttribute;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBHashKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBTable;

/**
 * Created by yinzcamvr on 4/22/2018.
 */

@DynamoDBTable(tableName = "ParkingStatusInfo")
public class MapperClass {
    String Sensor;
    String Status;


    @DynamoDBHashKey(attributeName = "Sensor")
    public String getSensor() {

        if(Sensor == null){
            Log.d("Gettin sensor", "null");
        }
        return Sensor;
    }

    public void setSensor(String sensor) {
        Sensor = sensor;
    }


    @DynamoDBAttribute(attributeName="Status")
    public String getStatus() {
        return Status;
    }
    public void setStatus(String status) {
        Status = status;
    }
}
