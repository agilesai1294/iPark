package com.example.yinzcamvr.parkingapp;

import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.CognitoCachingCredentialsProvider;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBMapper;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBMapperConfig;

public class MainActivity extends AppCompatActivity {

    private EditText username, password;
    private Button login;
    private TextView register;
    String user,pass;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        username = (EditText) findViewById(R.id.main_text_username);
        password = (EditText)findViewById(R.id.main_text_password);
        login = findViewById(R.id.button_login);
        register = findViewById(R.id.text_register);
        user = username.getText().toString();
        pass = password.getText().toString();
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //go to register activity for new users
                Intent intent = new Intent(MainActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Check Db for right values
                try {
                    new retrieveVals().execute();

                } catch (Exception e) {
                    Log.d("TERR","Error in callAsync");
                }

            }
        });
    }

    private class retrieveVals extends AsyncTask<Void, Integer, Integer> {

        @Override
        protected Integer doInBackground(Void... voids) {
            try {
                ManagerClass managerClass = new ManagerClass();
                CognitoCachingCredentialsProvider credentialsProvider = managerClass.getCredentials(MainActivity.this);
                LoginMapperClass mapperClass = new LoginMapperClass();

                if (credentialsProvider != null && mapperClass != null) {
                    Log.d("credentialsProvider:", String.valueOf(credentialsProvider));
                    DynamoDBMapper dynamoDBMapper = managerClass.initDynamoClient(credentialsProvider);
                    DynamoDBMapperConfig dynamoDBMapperConfig = new DynamoDBMapperConfig(DynamoDBMapperConfig.SaveBehavior.UPDATE);
                    mapperClass.setUsername(String.valueOf(username.getText()));
                    LoginMapperClass mapperClass1 = new LoginMapperClass();
                    mapperClass1 = dynamoDBMapper.load(LoginMapperClass.class, mapperClass.getUsername(),
                            new DynamoDBMapperConfig(DynamoDBMapperConfig.ConsistentReads.CONSISTENT));
                    if(mapperClass1 == null){
                        MainActivity.this.runOnUiThread(new Runnable() {
                            public void run() {
                                
                                Toast.makeText(MainActivity.this, "Username or Password is incorrect", Toast.LENGTH_LONG).show();
                            }
                        });
                    }else{

                        if(( username.getText().toString().equals(String.valueOf(mapperClass1.getUsername()))) &&(password.getText().toString().equals(String.valueOf(mapperClass1.getPassword())))){

                            Intent intent = new Intent(MainActivity.this, HomeActivity.class);
                            startActivity(intent);

                        }else{

                            MainActivity.this.runOnUiThread(new Runnable() {
                                public void run() {
                                    Toast.makeText(MainActivity.this, "Username or Password is incorrect", Toast.LENGTH_LONG).show();
                                }
                            });
                        }
                    }


                } else {
                    return 2;
                }


            } catch (AmazonServiceException ase) {
                Log.d("Exception", " Caught! ");
            }

            return 1;
        }

        @Override
        protected void onPostExecute(Integer integer) {
            super.onPostExecute(integer);
            if (integer == 2) {
                Toast.makeText(MainActivity.this, "Not Updated", Toast.LENGTH_SHORT).show();
            }
        }

    }
}