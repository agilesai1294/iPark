package com.example.yinzcamvr.parkingapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {

    private EditText name,email,username,password;
    private Button register;

    String dbname,dbemail,dbusername,dbpassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        name = findViewById(R.id.text_name);
        email = findViewById(R.id.text_email);
        username = findViewById(R.id.text_username);
        password = findViewById(R.id.text_password);
        register = findViewById(R.id.button_register);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dbname = name.getText().toString();
                dbemail = email.getText().toString();
                dbusername = username.getText().toString();
                dbpassword = password.getText().toString();

                //add to dynamodb

                Toast.makeText(getApplicationContext(),"Registered",Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}
